let row = 3;
let coordinate = "23";

// Your code here