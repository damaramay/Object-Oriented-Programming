let exercise = '<>^v>>>'
let userInput = '<>^^>><'

// Your code here
