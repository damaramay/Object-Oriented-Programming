let wahana = "Wahana Utara"
let usia = 28
let saldo = 180000

// code here
let tarif;