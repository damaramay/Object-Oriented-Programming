// special training
// => kasih timer 3 menit
// => kalau udah selesai, hapus lagi dan ulang lagi

// 10:26

/*
Halo pak, bu

Buatlah sebuah aplikasi yang menerima 2 input, yaitu nama dan kelamin yang bertipe data string. Untuk input data kelamin hanya ada 2 (pria atau wanita). Jika user menginputkan pria, cetak tulisan 'halo pak' diikuti dengan namanya, jika user memilih wanita, cetak tulisan 'halo bu' diikuti dengan namanya, seperti contoh output berikut.

contoh 1:
input:
nama: Amin
kelamin: pria
output: 'halo pak Amin'

contoh 2:
input: Tuti
kelamin: wanita
output: 'halo bu Tuti'

*/
let nama = 'rino' // isi variabel ini boleh diganti untuk mencoba kasus lain
let kelamin  = 'pria' // isi variabel ini boleh diganti untuk mencoba kasus lain
