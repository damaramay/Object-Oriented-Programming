/*
Buatlah sebuah proses yang akan menerima 1 input angka berupa number, dan akan menghasilkan sebuat output berupa string dengan aturan seperti yang dijelaskan di bawah ini:
- input number harus angka 1 - 4
- apabila angka adalah 1 maka outputnya 'Januari'
- apabila angka adalah 2 maka outputnya 'Februari'
- apabila angka adalah 3 maka outputnya 'Maret'
- apabila angka adalah 4 maka outputnya 'April'
- apabila angka selain 1 - 4 maka outputnya 'Nomor bulan harus 1 - 4'
*/

let angka = 1;