/*
Buatlah sebuah proses yang memiliki 1 input nilai berupa number dan akan menghasilkan output string seperti aturan dibawah ini :
- Jika nilai lebih dari atau sama dengan 100, sistem akan mengeluarkan “nilai anda 100 keatas”. 
- Jika nilai tidak 100 keatas tapi di atas 80, Maka sistem akan mengeluarkan “nilai anda diatas 80”. 
- Tapi, jika nilai tidak lebih besar dari 80, maka sistem mengeluarkan “nilai anda 80 kebawah” .
*/

let nilai  = 80;