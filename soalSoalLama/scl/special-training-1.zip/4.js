/*
Buatlah sebuah proses yang menerima 1 input nilai berupa number. Aplikasi ini akan menghasilkan output berupa string yang menjelaskan apakah nilai tersebut bernilai ganjil atau genap

contoh input:
nilai = 5
output: '5 merupakan angka ganjil'

nilai = 10
output: '10 merupakan angka genap'
*/

let nilai = 1283901829045;