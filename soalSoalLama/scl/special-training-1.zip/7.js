/*
Buatlah sebuah proses untuk membuat looping yang akan mencetak tulisan 'Javascript is so cool' sebanyak 20 kali dengan format sebagai berikut:

'[hitungan loop] - Javascript is so cool' 
*/

// tulis kode disini

// eksepektasi output
// 1 - Javascript is so cool
// 2 - Javascript is so cool
// 3 - Javascript is so cool
// 4 - Javascript is so cool
// 5 - Javascript is so cool
// 6 - Javascript is so cool
// 7 - Javascript is so cool
// 8 - Javascript is so cool
// 9 - Javascript is so cool
// 10 - Javascript is so cool
// 11 - Javascript is so cool
// 12 - Javascript is so cool
// 13 - Javascript is so cool
// 14 - Javascript is so cool
// 15 - Javascript is so cool
// 16 - Javascript is so cool
// 17 - Javascript is so cool
// 18 - Javascript is so cool
// 19 - Javascript is so cool
// 20 - Javascript is so cool