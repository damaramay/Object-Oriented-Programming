/*
Baby Boomer, Gen X, Gen Y, Gen Z

Berikut adalah beberapa istilah generasi berdasarkan tahun kelahirannya:

Baby boomer, kelahiran 1944 s.d 1964
Generasi X, kelahiran 1965 s.d 1979
Generasi Y (Millenials), kelahiran 1980 s.d 1994
Generasi Z, kelahiran 1995 s.d 2015
Buat sebuah proses yang menerima 2 input berupa nama (string) dan tahun (number). function akan mengeluarkan output berupa string berisikan nama dan generasinya seperti pada contoh output berikut.

input:
- nama: Santi
- tahun: 1994
output: 'Santi, berdasarkan tahun lahir anda tergolong Generasi Y'
*/

let nama = 'Santi'
let tahun = 1994